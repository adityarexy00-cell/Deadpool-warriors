DEADPOOL WARRIORS - NEW WEBSITE
Upload all four files to the ROOT of your GitHub Pages repository.
IMPORTANT: In script.js change ADMIN_PASSWORD='DW2026' before publishing.
Admin supports ADD, EDIT and DELETE players. Changes are stored in the browser with localStorage.
This is NOT a secure server-side admin system: the password exists in JavaScript and can be inspected. For true private cross-device management, a backend/database is required later.
